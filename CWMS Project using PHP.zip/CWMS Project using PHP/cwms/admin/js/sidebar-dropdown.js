/**
 * Admin Sidebar Dropdown Menu Functionality
 * Handles dropdown menus for Washing Points, Car Washing Booking, and Pages
 */

$(document).ready(function() {
    // Fast Dropdown Menu Functionality - No Delays
    function initSidebarDropdowns() {
        // Handle dropdown menu clicks with instant response
        $('#menu-washing-points > a, #menu-car-booking > a, #menu-pages > a').click(function(e) {
            e.preventDefault();

            var $parent = $(this).parent();
            var $submenu = $parent.find('ul');
            var $arrow = $(this).find('.fa-angle-right, .fa-angle-down');

            // Instant toggle submenu - no animation delays
            if ($submenu.is(':visible')) {
                // Close this submenu instantly
                $submenu.hide();
                $arrow.removeClass('fa-angle-down').addClass('fa-angle-right');
                $parent.removeClass('active');
            } else {
                // Close other open submenus instantly
                $('#menu li ul:visible').hide();
                $('#menu .fa-angle-down').removeClass('fa-angle-down').addClass('fa-angle-right');
                $('#menu li.active').removeClass('active');

                // Open clicked submenu instantly
                $submenu.show();
                $arrow.removeClass('fa-angle-right').addClass('fa-angle-down');
                $parent.addClass('active');
            }
        });

        // Fast hover effects for better UX
        $('#menu-washing-points > a, #menu-car-booking > a, #menu-pages > a').hover(
            function() {
                $(this).addClass('dropdown-hover');
            },
            function() {
                $(this).removeClass('dropdown-hover');
            }
        );

        // Close submenus when clicking outside
        $(document).click(function(e) {
            if (!$(e.target).closest('#menu').length) {
                $('#menu li ul:visible').hide();
                $('#menu .fa-angle-down').removeClass('fa-angle-down').addClass('fa-angle-right');
                $('#menu li.active').removeClass('active');
            }
        });

        // Highlight current page in submenu
        highlightCurrentPage();
    }
    
    // Function to highlight current page in submenu
    function highlightCurrentPage() {
        var currentPage = window.location.pathname.split('/').pop();
        
        // Find the current page link in submenus
        $('#menu li ul li a').each(function() {
            var linkHref = $(this).attr('href');
            if (linkHref === currentPage) {
                // Highlight the current submenu item
                $(this).addClass('current-page');
                
                // Open the parent dropdown
                var $parentLi = $(this).closest('#menu > li');
                var $submenu = $parentLi.find('ul');
                var $arrow = $parentLi.find('.fa-angle-right');
                
                $submenu.show();
                $arrow.removeClass('fa-angle-right').addClass('fa-angle-down');
                $parentLi.addClass('active');
            }
        });
    }
    
    // Initialize dropdown functionality
    initSidebarDropdowns();
});
