<div class="copyrights">
    <div class="footer-content">
        <div class="footer-logo">
            <h4>⚡ CWMS</h4>
            <span>Premium Car Wash Management</span>
        </div>
        <div class="footer-text">
            <p>© <?php echo date('Y');?> Car Wash Management System. All Rights Reserved</p>
            <p>Powered by <span class="highlight">Advanced Dashboard Technology</span></p>
        </div>
    </div>
</div>

<style>
.copyrights {
    background: linear-gradient(135deg, rgba(218, 165, 32, 0.1) 0%, rgba(74, 144, 226, 0.05) 100%);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 15px;
    padding: 25px 30px;
    margin-top: 30px;
    position: relative;
    overflow: hidden;
}

.footer-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
}

.footer-logo h4 {
    margin: 0;
    font-family: 'Space Grotesk', sans-serif;
    font-size: 20px;
    font-weight: 700;
    background: linear-gradient(135deg, #DAA520 0%, #4A90E2 100%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
}

.footer-logo span {
    color: #94A3B8;
    font-size: 12px;
    font-weight: 400;
    display: block;
    margin-top: 5px;
}

.footer-text {
    text-align: right;
}

.footer-text p {
    margin: 5px 0;
    color: #94A3B8;
    font-size: 13px;
    font-weight: 400;
}

.footer-text .highlight {
    color: #DAA520;
    font-weight: 600;
}

@media (max-width: 768px) {
    .footer-content {
        flex-direction: column;
        text-align: center;
    }
    
    .footer-text {
        text-align: center;
    }
}
</style>
