<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
?>
<!DOCTYPE HTML>
<html>
<head>
<title>CWMS | Admin Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery-2.1.4.min.js"></script>
<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700;800;900&family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<!-- Lined Icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<!-- Custom Animations -->
<style>
.dashboard-welcome {
    background: linear-gradient(135deg, rgba(218, 165, 32, 0.1) 0%, rgba(74, 144, 226, 0.05) 100%);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 20px;
    padding: 25px 30px;
    margin-bottom: 30px;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.dashboard-welcome::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(218, 165, 32, 0.1), transparent);
    animation: shimmer 3s infinite;
}

@keyframes shimmer {
    0% { left: -100%; }
    100% { left: 100%; }
}

.welcome-title {
    font-family: 'Space Grotesk', sans-serif;
    font-size: 28px;
    font-weight: 700;
    background: linear-gradient(135deg, #DAA520 0%, #4A90E2 100%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 10px;
    position: relative;
    z-index: 2;
}

.welcome-subtitle {
    color: #94A3B8;
    font-size: 16px;
    font-weight: 400;
    position: relative;
    z-index: 2;
}

.stats-animation {
    animation: fadeInUp 0.8s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card-pulse {
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% {
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    }
    50% {
        box-shadow: 0 15px 35px rgba(218, 165, 32, 0.25);
    }
    100% {
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    }
}

/* Enhanced Box Alignment */
.stats-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
    max-width: 1400px;
    margin: 0 auto;
}

.stats-row {
    width: 100%;
    display: flex;
    justify-content: center;
    gap: 25px;
    margin-bottom: 25px;
    flex-wrap: wrap;
}

.stats-row.first-row {
    justify-content: space-evenly;
}

.stats-row.second-row {
    justify-content: center;
    max-width: 700px;
    margin: 0 auto;
}

/* Ensure equal card heights */
.four-grid .four-agileits,
.four-grid .four-agileinfo,
.four-grid .four-w3ls,
.four-grid .four-wthree {
    height: 200px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

@media (max-width: 768px) {
    .stats-row {
        flex-direction: column;
        align-items: center;
        gap: 20px;
    }
    
    .stats-row.first-row,
    .stats-row.second-row {
        max-width: 100%;
    }
}
</style>
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
    <div class="content-wrapper">
        <!--header start here-->
        <?php include('includes/header.php');?>
        <!--header end here-->
        
        <!-- Welcome Section -->
        <div class="dashboard-welcome">
            <h2 class="welcome-title">Welcome to Car Wash Management System</h2>
            <p class="welcome-subtitle">Manage your car wash business with style and efficiency</p>
        </div>
        
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Home</a> <i class="fa fa-angle-right"></i></li>
        </ol>
        
        <!--four-grids here-->
        <div class="stats-container">
            <!-- First Row: 3 Cards - Justified Distribution -->
            <div class="four-grids stats-animation">

		<a href="all-bookings.php" target="_blank">
				<div class="col-md-3 four-grid">
					<div class="four-agileits card-pulse">
						<div class="icon">
								<i class="fa fa-calendar-check-o" aria-hidden="true"></i>
						</div>
						<div class="four-text">
							<h3>Total Bookings</h3>

								<?php $sql = "SELECT id from tblcarwashbooking";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=$query->rowCount();
					?>			<h4> <?php echo htmlentities($cnt);?> </h4>


						</div>

					</div>
				</div>
			</a>
<a href="new-booking.php" target="_blank">
					<div class="col-md-3 four-grid">
						<div class="four-agileinfo">
							<div class="icon">
								<i class="fa fa-plus-circle" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3>New Bookings</h3>
							<?php $sql1 = "SELECT id from tblcarwashbooking  where status='New'";
$query1 = $dbh -> prepare($sql1);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$newbookings=$query1->rowCount();
					?>
								<h4><?php echo htmlentities($newbookings);?></h4>

							</div>

						</div>
					</div>
				</a>
		<a href="completed-booking.php" target="_blank">
					<div class="col-md-3 four-grid">
						<div class="four-wthree">
							<div class="icon">
							<i class="fa fa-check-circle" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3>Completed Bookings</h3>
<?php $sql3 = "SELECT id from tblcarwashbooking  where status='Completed'";
$query3= $dbh -> prepare($sql3);
$query3->execute();
$results3=$query3->fetchAll(PDO::FETCH_OBJ);
$completedbookings=$query3->rowCount();
					?>
								<h4><?php echo htmlentities($completedbookings);?></h4>

							</div>

						</div>
					</div>
</a>

					<div class="clearfix"></div>
				</div>

		<!-- Second Row: 2 Cards - Justified Distribution -->
		<div class="four-grids">
	<a href="manage-enquires.php" target="_blank">
			<div class="col-md-3 four-grid">
						<div class="four-w3ls">
							<div class="icon">
								<i class="fa fa-envelope-o" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3>Enquiries</h3>
										<?php $sql2 = "SELECT id from tblenquiry";
$query2= $dbh -> prepare($sql2);
$query2->execute();
$results2=$query2->fetchAll(PDO::FETCH_OBJ);
$cnt2=$query2->rowCount();
					?>
								<h4><?php echo htmlentities($cnt2);?></h4>

							</div>

						</div>
					</div>
				</a>
			<a href="managecar-washingpoints.php" target="_blank">
					<div class="col-md-3 four-grid">
						<div class="four-w3ls">
							<div class="icon">
								<i class="fa fa-map-marker" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3>Washing Points</h3>
												<?php $sql5 = "SELECT id from tblwashingpoints";
$query5= $dbh -> prepare($sql5);
$query5->execute();
$results5=$query5->fetchAll(PDO::FETCH_OBJ);
$washingpoints=$query5->rowCount();
					?>
								<h4><?php echo htmlentities($washingpoints);?></h4>

							</div>

						</div>
					</div>
</a>

					<div class="clearfix"></div>
				</div>
        </div>
        <!--//four-grids here-->


<div class="inner-block">

</div>
<!--inner block end here-->
        <!--copy rights start here-->
        <?php include('includes/footer.php');?>
    </div>
</div>

			<!--/sidebar-menu-->
				<?php include('includes/sidebarmenu.php');?>
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});


							</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Sidebar Dropdown Functionality -->
<script src="js/sidebar-dropdown.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->	   
<!-- morris JavaScript -->	
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<script>
	$(document).ready(function() {
		//BOX BUTTON SHOW AND CLOSE
	   jQuery('.small-graph-box').hover(function() {
		  jQuery(this).find('.box-button').fadeIn('fast');
	   }, function() {
		  jQuery(this).find('.box-button').fadeOut('fast');
	   });
	   jQuery('.small-graph-box .box-close').click(function() {
		  jQuery(this).closest('.small-graph-box').fadeOut(200);
		  return false;
	   });
	   
	    //CHARTS
	    function gd(year, day, month) {
			return new Date(year, month - 1, day).getTime();
		}
		
		graphArea2 = Morris.Area({
			element: 'hero-area',
			padding: 10,
        behaveLikeLine: true,
        gridEnabled: false,
        gridLineColor: '#dddddd',
        axes: true,
        resize: true,
        smooth:true,
        pointSize: 0,
        lineWidth: 0,
        fillOpacity:0.85,
			data: [
				{period: '2014 Q1', iphone: 2668, ipad: null, itouch: 2649},
				{period: '2014 Q2', iphone: 15780, ipad: 13799, itouch: 12051},
				{period: '2014 Q3', iphone: 12920, ipad: 10975, itouch: 9910},
				{period: '2014 Q4', iphone: 8770, ipad: 6600, itouch: 6695},
				{period: '2015 Q1', iphone: 10820, ipad: 10924, itouch: 12300},
				{period: '2015 Q2', iphone: 9680, ipad: 9010, itouch: 7891},
				{period: '2015 Q3', iphone: 4830, ipad: 3805, itouch: 1598},
				{period: '2015 Q4', iphone: 15083, ipad: 8977, itouch: 5185},
				{period: '2016 Q1', iphone: 10697, ipad: 4470, itouch: 2038},
				{period: '2016 Q2', iphone: 8442, ipad: 5723, itouch: 1801}
			],
			lineColors:['#ff4a43','#a2d200','#22beef'],
			xkey: 'period',
            redraw: true,
            ykeys: ['iphone', 'ipad', 'itouch'],
            labels: ['All Visitors', 'Returning Visitors', 'Unique Visitors'],
			pointSize: 2,
			hideHover: 'auto',
			resize: true
		});
		
	   
	});
	</script>
	
<!-- Custom Dashboard Enhancements -->
<script>
$(document).ready(function() {
    // Animate stats cards on load
    $('.four-grid').each(function(index) {
        $(this).css('animation-delay', (index * 0.2) + 's');
    });
    
    // Add hover effects to cards
    $('.four-grid').hover(
        function() {
            $(this).find('.icon i').addClass('fa-spin');
        },
        function() {
            $(this).find('.icon i').removeClass('fa-spin');
        }
    );
    
    // Count up animation for numbers
    $('.four-text h4').each(function() {
        var $this = $(this);
        var countTo = parseInt($this.text());
        
        $({ countNum: 0 }).animate({
            countNum: countTo
        }, {
            duration: 2000,
            easing: 'swing',
            step: function() {
                $this.text(Math.floor(this.countNum));
            },
            complete: function() {
                $this.text(this.countNum);
            }
        });
    });
});
</script>
</body>
</html>
<?php } ?>