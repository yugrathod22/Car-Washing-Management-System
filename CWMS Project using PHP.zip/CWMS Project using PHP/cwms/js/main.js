(function ($) {
    "use strict";
    
    // loader
    var loader = function () {
        setTimeout(function () {
            if ($('#loader').length > 0) {
                $('#loader').removeClass('show');
            }
        }, 1);
    };
    loader();
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 200) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });
    
    
    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 90) {
            $('.nav-bar').addClass('nav-sticky');
            $('.carousel, .page-header').css("margin-top", "73px");
        } else {
            $('.nav-bar').removeClass('nav-sticky');
            $('.carousel, .page-header').css("margin-top", "0");
        }
    });
    
    
    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });

    
    // Main carousel
    $(".carousel .owl-carousel").owlCarousel({
        autoplay: true,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        items: 1,
        smartSpeed: 300,
        dots: false,
        loop: true,
        nav : true,
        navText : [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ]
    });

    
    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // Testimonials carousel
    $(".testimonials-carousel").owlCarousel({
        center: true,
        autoplay: true,
        smartSpeed: 2000,
        dots: true,
        loop: true,
        responsive: {
            0:{
                items:1
            },
            576:{
                items:1
            },
            768:{
                items:2
            },
            992:{
                items:3
            }
        }
    });
    
    
    // Related post carousel
    $(".related-slider").owlCarousel({
        autoplay: true,
        dots: false,
        loop: true,
        nav : true,
        navText : [
            '<i class="fa fa-angle-left" aria-hidden="true"></i>',
            '<i class="fa fa-angle-right" aria-hidden="true"></i>'
        ],
        responsive: {
            0:{
                items:1
            },
            576:{
                items:1
            },
            768:{
                items:2
            }
        }
    });

    // Enhanced Navigation Active State
    $(document).ready(function() {
        // Add smooth transition for active nav items
        $('.navbar-nav .nav-link').on('click', function() {
            // Remove active class from all nav items
            $('.navbar-nav .nav-link').removeClass('active');
            // Add active class to clicked item
            $(this).addClass('active');
        });

        // Enhance active state visual feedback
        $('.navbar-nav .nav-link.active').each(function() {
            $(this).css({
                'background': 'rgba(232, 28, 46, 0.15)',
                'color': '#ffffff',
                'font-weight': '700'
            });
        });
    });

    // Enhanced Washing Plans Interactions
    $(document).ready(function() {
        // Pricing card hover effects and animations
        $('.price-item').each(function(index) {
            $(this).css('animation-delay', (index * 0.1) + 's');
        });

        // Add ripple effect to pricing cards
        $('.price-item').addClass('ripple-effect');

        // Enhanced modal interactions
        $('#myModal').on('show.bs.modal', function(e) {
            // Add entrance animation
            $(this).find('.modal-content').addClass('animated fadeInDown');
            
            // Focus on first input field
            setTimeout(function() {
                $('#myModal select[name="packagetype"]').focus();
            }, 500);
        });

        // Auto-populate package type based on clicked button
        $('.price-footer .btn').on('click', function(e) {
            var priceItem = $(this).closest('.price-item');
            var packageType = '';
            
            if (priceItem.find('h3').text().includes('Essential')) {
                packageType = '1';
            } else if (priceItem.find('h3').text().includes('Premium')) {
                packageType = '2';
            } else if (priceItem.find('h3').text().includes('Deluxe')) {
                packageType = '3';
            } else if (priceItem.find('h3').text().includes('Royal')) {
                packageType = '4';
            }
            
            setTimeout(function() {
                $('select[name="packagetype"]').val(packageType);
            }, 300);
        });

        // Form validation enhancements
        $('#myModal form').on('submit', function(e) {
            var isValid = true;
            var errorMessages = [];

            // Validate required fields
            $(this).find('[required]').each(function() {
                if (!$(this).val()) {
                    isValid = false;
                    var fieldName = $(this).attr('placeholder') || $(this).attr('name');
                    errorMessages.push(fieldName + ' is required');
                    $(this).addClass('is-invalid');
                } else {
                    $(this).removeClass('is-invalid');
                }
            });

            // Validate mobile number
            var mobile = $('input[name="contactno"]').val();
            if (mobile && !/^[0-9]{10}$/.test(mobile)) {
                isValid = false;
                errorMessages.push('Please enter a valid 10-digit mobile number');
                $('input[name="contactno"]').addClass('is-invalid');
            }

            // Validate date (should be future date)
            var washDate = $('input[name="washdate"]').val();
            if (washDate) {
                var selectedDate = new Date(washDate);
                var today = new Date();
                today.setHours(0, 0, 0, 0);
                
                if (selectedDate < today) {
                    isValid = false;
                    errorMessages.push('Please select a future date');
                    $('input[name="washdate"]').addClass('is-invalid');
                }
            }

            if (!isValid) {
                e.preventDefault();
                alert('Please fix the following errors:\n' + errorMessages.join('\n'));
                return false;
            }
        });

        // Real-time validation feedback
        $('#myModal input, #myModal select, #myModal textarea').on('input change', function() {
            $(this).removeClass('is-invalid');
            
            // Add real-time validation for mobile number
            if ($(this).attr('name') === 'contactno') {
                var value = $(this).val();
                if (value && !/^[0-9]{10}$/.test(value)) {
                    $(this).addClass('is-invalid');
                } else {
                    $(this).removeClass('is-invalid');
                }
            }
        });

        // Smooth scroll to pricing section
        $('a[href*="washing-plans"]').on('click', function(e) {
            if ($(this).attr('href') === 'washing-plans.php') return;
            
            e.preventDefault();
            $('html, body').animate({
                scrollTop: $('.price').offset().top - 100
            }, 1000, 'easeInOutExpo');
        });

        // Add loading state to booking button
        $('#myModal form').on('submit', function() {
            var submitBtn = $(this).find('input[type="submit"]');
            submitBtn.val('Processing...').prop('disabled', true);
            
            // Re-enable button after a delay if form submission fails
            setTimeout(function() {
                submitBtn.val('Book Now').prop('disabled', false);
            }, 10000);
        });

        // Price comparison tooltip
        $('.price-item').hover(
            function() {
                $(this).find('.price-header').append('<div class="tooltip-compare" style="position: absolute; bottom: -30px; left: 50%; transform: translateX(-50%); background: rgba(0,0,0,0.8); color: white; padding: 5px 10px; border-radius: 5px; font-size: 12px; white-space: nowrap;">Click to compare features</div>');
            },
            function() {
                $(this).find('.tooltip-compare').remove();
            }
        );

        // Featured plan pulse animation
        setInterval(function() {
            $('.featured-item').addClass('pulse-animation');
            setTimeout(function() {
                $('.featured-item').removeClass('pulse-animation');
            }, 1000);
        }, 5000);

        // Add CSS for pulse animation
        $('<style>').text(`
            .pulse-animation {
                animation: pulse 1s ease-in-out !important;
            }
            @keyframes pulse {
                0% { transform: scale(1.08); }
                50% { transform: scale(1.12); }
                100% { transform: scale(1.08); }
            }
            .is-invalid {
                border-color: #e74c3c !important;
                box-shadow: 0 0 10px rgba(231, 76, 60, 0.3) !important;
            }
        `).appendTo('head');
    });

    // Enhanced Contact Form Interactions
    $(document).ready(function() {
        // Contact form enhancements
        if ($('.contact-form').length) {
            // Add floating label effect
            $('.contact-form .form-control').on('focus blur', function(e) {
                var $this = $(this);
                var label = $this.prev('label');
                
                if (e.type === 'focus' || this.value.length > 0) {
                    $this.addClass('has-value');
                } else {
                    $this.removeClass('has-value');
                }
            });

            // Enhanced form validation
            $('.contact-form form').on('submit', function(e) {
                var isValid = true;
                var errorMessages = [];
                var form = $(this);

                // Add loading state to submit button
                var submitBtn = form.find('.btn-custom');
                submitBtn.addClass('loading').text('Sending...');

                // Validate required fields
                form.find('[required]').each(function() {
                    var $field = $(this);
                    var value = $field.val().trim();
                    
                    if (!value) {
                        isValid = false;
                        $field.addClass('is-invalid');
                        errorMessages.push($field.attr('placeholder') + ' is required');
                    } else {
                        $field.removeClass('is-invalid').addClass('is-valid');
                    }
                });

                // Email validation
                var email = form.find('input[type="email"]').val();
                var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (email && !emailRegex.test(email)) {
                    isValid = false;
                    form.find('input[type="email"]').addClass('is-invalid');
                    errorMessages.push('Please enter a valid email address');
                }

                if (!isValid) {
                    e.preventDefault();
                    submitBtn.removeClass('loading').text('Send Message');
                    
                    // Show error messages
                    var errorHtml = '<div class="alert alert-danger">' + errorMessages.join('<br>') + '</div>';
                    form.find('#success').html(errorHtml).addClass('show');
                    
                    // Remove error after 5 seconds
                    setTimeout(function() {
                        form.find('#success').removeClass('show').empty();
                    }, 5000);
                    
                    return false;
                }
            });

            // Real-time validation feedback
            $('.contact-form input, .contact-form textarea').on('input', function() {
                var $this = $(this);
                $this.removeClass('is-invalid is-valid');
                
                if ($this.attr('type') === 'email') {
                    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if ($this.val() && emailRegex.test($this.val())) {
                        $this.addClass('is-valid');
                    }
                } else if ($this.val().trim().length > 0) {
                    $this.addClass('is-valid');
                }
            });

            // Add character counter for textarea
            var textarea = $('.contact-form textarea');
            if (textarea.length) {
                var maxLength = 500;
                textarea.attr('maxlength', maxLength);
                
                var counter = $('<div class="char-counter">' + maxLength + ' characters remaining</div>');
                textarea.after(counter);
                
                textarea.on('input', function() {
                    var remaining = maxLength - $(this).val().length;
                    counter.text(remaining + ' characters remaining');
                    
                    if (remaining < 50) {
                        counter.addClass('warning');
                    } else {
                        counter.removeClass('warning');
                    }
                });
            }

            // Smooth scroll to contact form
            $('a[href*="contact"]').on('click', function(e) {
                if ($(this).attr('href') === 'contact.php') return;
                
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: $('.contact').offset().top - 100
                }, 1000, 'easeInOutExpo');
            });

            // Add CSS for character counter
            $('<style>').text(`
                .char-counter {
                    font-size: 12px;
                    color: #7f8c8d;
                    text-align: right;
                    margin-top: 5px;
                    transition: color 0.3s ease;
                }
                .char-counter.warning {
                    color: #e74c3c;
                    font-weight: 600;
                }
                .contact-form .form-control.has-value {
                    border-color: #3498db;
                }
            `).appendTo('head');
        }
    });

})(jQuery);

