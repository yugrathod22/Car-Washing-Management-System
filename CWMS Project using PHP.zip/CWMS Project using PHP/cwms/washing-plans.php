<?php //error_reporting(0);
include('includes/config.php'); 

if(isset($_POST['book']))
{
$ptype=$_POST['packagetype'];
$wpoint=$_POST['washingpoint'];   
$fname=$_POST['fname'];
$mobile=$_POST['contactno'];
$date=$_POST['washdate'];
$time=$_POST['washtime'];
$message=$_POST['message'];
$status='New';
$bno=mt_rand(100000000, 999999999);
$sql="INSERT INTO tblcarwashbooking(bookingId,packageType,carWashPoint,fullName,mobileNumber,washDate,washTime,message,status) VALUES(:bno,:ptype,:wpoint,:fname,:mobile,:date,:time,:message,:status)";
$query = $dbh->prepare($sql);
$query->bindParam(':bno',$bno,PDO::PARAM_STR);
$query->bindParam(':ptype',$ptype,PDO::PARAM_STR);
$query->bindParam(':wpoint',$wpoint,PDO::PARAM_STR);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':mobile',$mobile,PDO::PARAM_STR);
$query->bindParam(':date',$date,PDO::PARAM_STR);
$query->bindParam(':time',$time,PDO::PARAM_STR);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
 
  echo '<script>alert("Your booking done successfully. Booking number is "+"'.$bno.'")</script>';
 echo "<script>window.location.href ='washing-plans.php'</script>";
}
else 
{
 echo "<script>alert('Something went wrong. Please try again.');</script>";
}

}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>CWMS | Washing Plans</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Free Website Template" name="keywords">
        <meta content="Free Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css?v=<?php echo time(); ?>" rel="stylesheet">
    </head>

    <body>
    
        <?php include_once('includes/header.php');?>
        
        <!-- Page Header Start -->
        <div class="page-header">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2>Washing Plan</h2>
                    </div>
                    <div class="col-12">
                        <a href="index.php">Home</a>
                        <a href="washing-plans.php">Price</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Header End -->
        
        
        <!-- Price Start -->
        <div class="price">
            <div class="container">
                <div class="section-header text-center">
                    <p>Washing Plans</p>
                    <h2>Choose Your Plan</h2>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-3 col-md-6 mb-5 px-4">
                        <div class="price-item-simple">
                            <div class="price-header-simple">
                                <h3>Essential Clean</h3>
                                <div class="price-simple">₹899</div>
                            </div>
                            <div class="price-body-simple">
                                <p>Perfect for regular maintenance</p>
                                <ul class="features-simple">
                                    <li>✓ Exterior Wash</li>
                                    <li>✓ Interior Vacuum</li>
                                    <li>✓ Tire Cleaning</li>
                                    <li>✓ Dashboard Wipe</li>
                                </ul>
                            </div>
                            <div class="price-footer-simple">
                                <a class="btn btn-simple" data-toggle="modal" data-target="#myModal">Book Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-5 px-4">
                        <div class="price-item-simple featured-simple">
                            <div class="price-header-simple">
                                <h3>Premium Care</h3>
                                <div class="price-simple">₹1,699</div>
                            </div>
                            <div class="price-body-simple">
                                <p>Complete cleaning solution</p>
                                <ul class="features-simple">
                                    <li>✓ Complete Exterior Wash</li>
                                    <li>✓ Deep Interior Clean</li>
                                    <li>✓ Seat Cleaning</li>
                                    <li>✓ Window & Mirror Clean</li>
                                    <li>✓ Basic Wax</li>
                                </ul>
                            </div>
                            <div class="price-footer-simple">
                                <a class="btn btn-simple" data-toggle="modal" data-target="#myModal">Book Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-5 px-4">
                        <div class="price-item-simple">
                            <div class="price-header-simple">
                                <h3>Deluxe Detail</h3>
                                <div class="price-simple">₹2,499</div>
                            </div>
                            <div class="price-body-simple">
                                <p>Premium detailing service</p>
                                <ul class="features-simple">
                                    <li>✓ Premium Exterior Wash</li>
                                    <li>✓ Complete Interior Detail</li>
                                    <li>✓ Leather Conditioning</li>
                                    <li>✓ Engine Bay Cleaning</li>
                                    <li>✓ Premium Wax & Polish</li>
                                    <li>✓ Tire Shine</li>
                                </ul>
                            </div>
                            <div class="price-footer-simple">
                                <a class="btn btn-simple" data-toggle="modal" data-target="#myModal">Book Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-5 px-4">
                        <div class="price-item-simple royal-vintage-simple">
                            <div class="price-header-simple">
                                <h3>Royal & Vintage Care</h3>
                                <div class="price-simple">₹4,999</div>
                            </div>
                            <div class="price-body-simple">
                                <p>Ultimate luxury car care experience</p>
                                <ul class="features-simple">
                                    <li>✓ Specialized Hand Wash</li>
                                    <li>✓ Vintage Paint Restoration</li>
                                    <li>✓ Chrome & Metal Polishing</li>
                                    <li>✓ Leather Restoration</li>
                                    <li>✓ Engine Bay Detailing</li>
                                    <li>✓ Classic Car Protection</li>
                                    <li>✓ Vintage Parts Care</li>
                                    <li>✓ White Glove Service</li>
                                </ul>
                            </div>
                            <div class="price-footer-simple">
                                <a class="btn btn-simple" data-toggle="modal" data-target="#myModal">Book Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Price End -->
        
       <?php include_once('includes/footer.php');?>

<!--Model-->
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Car Wash Booking</h4>
        </div>
        <div class="modal-body">
<form method="post">   
  <p>
            <select name="packagetype" required class="form-control">
                <option value="">Package Type</option>
                <option value="1">ESSENTIAL CLEAN (₹899)</option>
                 <option value="2">PREMIUM CARE (₹1,699)</option>
                  <option value="3">DELUXE DETAIL (₹2,499)</option>
                  <option value="4">ROYAL & VINTAGE CARE (₹4,999)</option>
              </select>

          <p>
            <select name="washingpoint" required class="form-control">
                <option value="">Select Washing Point</option>
<?php $sql = "SELECT * from tblwashingpoints";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
foreach($results as $result)
{               ?>  
    <option value="<?php echo htmlentities($result->id);?>"><?php echo htmlentities($result->washingPointName);?> (<?php echo htmlentities($result->washingPointAddress);?>)</option>
<?php } ?>
            </select></p>
            <p><input type="text" name="fname" class="form-control" required placeholder="Full Name"></p>
            <p><input type="text" name="contactno" class="form-control" pattern="[0-9]{10}" title="10 numeric characters only" required placeholder="Mobile No."></p>
            <p>Wash Date <br /><input type="date" name="washdate" required class="form-control"></p>
             <p>Wash Time <br /><input type="time" name="washtime" required class="form-control"></p>
             <p><textarea name="message"  class="form-control" placeholder="Message if any"></textarea></p>
             <p><input type="submit" class="btn btn-custom" name="book" value="Book Now"></p>
      </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/counterup/counterup.min.js"></script>
        
        <!-- Contact Javascript File -->
        <script src="mail/jqBootstrapValidation.min.js"></script>
        <script src="mail/contact.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
    </body>
</html>
