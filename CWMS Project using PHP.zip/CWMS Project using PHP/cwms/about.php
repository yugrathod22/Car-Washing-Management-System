<?php //error_reporting(0);
include('includes/config.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Car Wash management System | About Us Page</title>
   

        <!-- Google Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
<?php include_once('includes/header.php');?>
        <!-- Page Header Start -->
        <div class="page-header">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2>About Us</h2>
                    </div>
                    <div class="col-12">
                        <a href="index.php">Home</a>
                        <a href="about.php">About Us</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Header End -->
        

        <!-- About Start -->
        <div class="about">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-img">
                            <img src="img/3.jpg" alt="Professional Car Washing Service">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="section-header text-left">
                            <p>About Our Company</p>
                            <h2>Premium Car Care & Detailing Experts</h2>
                        </div>
                        <div class="about-content">
                            <p class="lead">
                                Welcome to the premier car washing and detailing service in the city. With over 15 years of experience, we have established ourselves as the trusted choice for car owners who demand excellence and quality.
                            </p>
                            <p>
                                Our state-of-the-art facility combines cutting-edge technology with eco-friendly practices to deliver exceptional results. We use only premium products and employ skilled professionals who are passionate about making your vehicle look its absolute best.
                            </p>
                            <p>
                                From basic exterior washes to comprehensive detailing packages, we offer a complete range of services designed to meet every customer's needs and budget. Our commitment to quality and customer satisfaction has made us the preferred choice for thousands of satisfied customers.
                            </p>

                            <div class="services-highlight">
                                <h4>Our Core Services</h4>
                                <ul>
                                    <li><i class="far fa-check-circle"></i>Professional Exterior Washing & Waxing</li>
                                    <li><i class="far fa-check-circle"></i>Complete Interior Detailing & Cleaning</li>
                                    <li><i class="far fa-check-circle"></i>Advanced Vacuum & Steam Cleaning</li>
                                    <li><i class="far fa-check-circle"></i>Engine Bay Cleaning & Maintenance</li>
                                    <li><i class="far fa-check-circle"></i>Leather Treatment & Conditioning</li>
                                    <li><i class="far fa-check-circle"></i>Paint Protection & Ceramic Coating</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->

        <!-- Company Stats Start -->
        <div class="company-stats">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-item">
                            <div class="stat-icon">
                                <i class="fas fa-car"></i>
                            </div>
                            <div class="stat-content">
                                <h3>15,000+</h3>
                                <p>Cars Washed</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-item">
                            <div class="stat-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="stat-content">
                                <h3>8,500+</h3>
                                <p>Happy Customers</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-item">
                            <div class="stat-icon">
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <div class="stat-content">
                                <h3>15+</h3>
                                <p>Years Experience</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-item">
                            <div class="stat-icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="stat-content">
                                <h3>25+</h3>
                                <p>Service Points</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Company Stats End -->

        <!-- Why Choose Us Start -->
        <div class="why-choose-us">
            <div class="container">
                <div class="section-header text-center">
                    <p>Why Choose Us</p>
                    <h2>What Makes Us Different</h2>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-item">
                            <div class="feature-icon">
                                <i class="fas fa-leaf"></i>
                            </div>
                            <div class="feature-content">
                                <h4>Eco-Friendly Products</h4>
                                <p>We use only biodegradable, environmentally safe cleaning products that are gentle on your car and the planet.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-item">
                            <div class="feature-icon">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <div class="feature-content">
                                <h4>Quality Guarantee</h4>
                                <p>100% satisfaction guarantee on all our services. If you're not completely satisfied, we'll make it right.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-item">
                            <div class="feature-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="feature-content">
                                <h4>Quick & Efficient</h4>
                                <p>Professional service with quick turnaround times. Most services completed within 30-60 minutes.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-item">
                            <div class="feature-icon">
                                <i class="fas fa-tools"></i>
                            </div>
                            <div class="feature-content">
                                <h4>Advanced Equipment</h4>
                                <p>State-of-the-art washing equipment and tools ensure the best possible results for your vehicle.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-item">
                            <div class="feature-icon">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div class="feature-content">
                                <h4>Expert Team</h4>
                                <p>Our trained professionals have years of experience and are passionate about delivering exceptional results.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-item">
                            <div class="feature-icon">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                            <div class="feature-content">
                                <h4>Competitive Pricing</h4>
                                <p>Premium quality services at affordable prices. We offer the best value for money in the market.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Why Choose Us End -->
        
        



  

<?php include_once('includes/footer.php');?>
        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/counterup/counterup.min.js"></script>
        
        <!-- Contact Javascript File -->
        <script src="mail/jqBootstrapValidation.min.js"></script>
        <script src="mail/contact.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
    </body>
</html>
